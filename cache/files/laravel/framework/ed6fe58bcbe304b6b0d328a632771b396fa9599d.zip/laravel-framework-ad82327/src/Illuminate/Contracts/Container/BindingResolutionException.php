<?php

namespace Illuminate\Contracts\Container;

use Exception;

class BindingResolutionException extends Exception
{
    //
}
